import { useMemo } from "react";
import ReactMarkdown from "react-markdown";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from "recharts";
import { cn } from "@/lib/utils";

interface ReportPreviewProps {
  content: string;
  theme: string;
  id?: string; // ID for targeting download
}

// Color palettes for charts
const COLORS = ["#6366f1", "#ec4899", "#8b5cf6", "#14b8a6", "#f59e0b"];

// Helper to parse chart blocks
const parseContentWithCharts = (text: string) => {
  if (!text) return [];

  const lines = text.split("\n");
  const blocks: Array<{ type: "text" | "chart"; content: any; chartType?: string }> = [];
  let currentBlock = "";
  let isChart = false;
  let chartType = "";
  let chartData: any[] = [];

  lines.forEach((line) => {
    const trimmed = line.trim();

    // Start of Chart Block
    if (trimmed.startsWith("[Chart:")) {
      // Save pending text
      if (currentBlock) {
        blocks.push({ type: "text", content: currentBlock });
        currentBlock = "";
      }
      isChart = true;
      chartType = trimmed.replace("[Chart:", "").replace("]", "").trim().toLowerCase();
      chartData = [];
      return;
    }

    // End of Chart Block
    if (trimmed === "[End]" && isChart) {
      blocks.push({ type: "chart", content: chartData, chartType });
      isChart = false;
      return;
    }

    // Inside Chart Block
    if (isChart) {
      const [label, value] = line.split(":").map((s) => s.trim());
      if (label && value && !isNaN(Number(value))) {
        chartData.push({ name: label, value: Number(value) });
      }
      return;
    }

    // Normal Text
    currentBlock += line + "\n";
  });

  // Flush remaining text
  if (currentBlock) {
    blocks.push({ type: "text", content: currentBlock });
  }

  return blocks;
};

export function ReportPreview({ content, theme, id }: ReportPreviewProps) {
  const blocks = useMemo(() => parseContentWithCharts(content), [content]);

  return (
    <div
      id={id}
      className={cn(
        "h-full w-full overflow-y-auto p-8 md:p-12 transition-colors duration-300 shadow-inner",
        theme === "modern"
          ? "bg-white text-slate-800 font-sans"
          : "theme-classic bg-[#f8f5f2] text-slate-900 font-serif border-l-8 border-double border-slate-300"
      )}
    >
      <div className="max-w-3xl mx-auto space-y-8 markdown-preview">
        {blocks.map((block, idx) => {
          if (block.type === "text") {
            return <ReactMarkdown key={idx}>{block.content}</ReactMarkdown>;
          }

          if (block.type === "chart" && block.content.length > 0) {
            return (
              <div
                key={idx}
                className={cn(
                  "my-8 p-6 rounded-xl border flex flex-col items-center justify-center",
                  theme === "modern"
                    ? "bg-slate-50 border-slate-100 shadow-sm"
                    : "bg-white border-2 border-slate-800 shadow-none"
                )}
              >
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground mb-6 w-full text-center border-b pb-2">
                  {block.chartType} Visualization
                </h4>
                
                <div className="h-[300px] w-full min-w-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    {block.chartType === "bar" ? (
                      <BarChart data={block.content}>
                        <CartesianGrid strokeDasharray="3 3" opacity={0.3} />
                        <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip 
                          cursor={{ fill: 'transparent' }}
                          contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        />
                        <Bar dataKey="value" fill={COLORS[0]} radius={[4, 4, 0, 0]} />
                      </BarChart>
                    ) : (
                      <PieChart>
                        <Pie
                          data={block.content}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={100}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {block.content.map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend verticalAlign="bottom" height={36}/>
                      </PieChart>
                    )}
                  </ResponsiveContainer>
                </div>
              </div>
            );
          }
          return null;
        })}
      </div>
    </div>
  );
}
