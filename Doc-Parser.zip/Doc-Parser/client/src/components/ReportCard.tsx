import { Link } from "wouter";
import { format } from "date-fns";
import { Trash2, FileText, ArrowRight } from "lucide-react";
import { type Report } from "@shared/schema";
import { motion } from "framer-motion";

interface ReportCardProps {
  report: Report;
  onDelete: (id: number) => void;
}

export function ReportCard({ report, onDelete }: ReportCardProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2 }}
      className="group relative bg-card hover:bg-card/50 border border-border/50 hover:border-primary/50 rounded-2xl p-6 shadow-sm hover:shadow-lg hover:shadow-primary/5 transition-all duration-300 flex flex-col h-full"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="p-3 rounded-xl bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors duration-300">
          <FileText className="w-6 h-6" />
        </div>
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (confirm("Are you sure you want to delete this report?")) {
              onDelete(report.id);
            }
          }}
          className="p-2 rounded-full text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors opacity-0 group-hover:opacity-100"
          title="Delete Report"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="flex-1">
        <h3 className="text-xl font-bold text-foreground mb-2 line-clamp-1 group-hover:text-primary transition-colors">
          {report.title}
        </h3>
        <p className="text-sm text-muted-foreground mb-4">
          Created on {format(new Date(report.createdAt || new Date()), "MMMM d, yyyy")}
        </p>
        <div className="flex items-center gap-2">
           <span className={`text-xs px-2 py-1 rounded-md font-medium border ${
             report.theme === 'modern' 
               ? 'bg-slate-100 text-slate-700 border-slate-200' 
               : 'bg-amber-50 text-amber-800 border-amber-200'
           }`}>
             {report.theme.charAt(0).toUpperCase() + report.theme.slice(1)} Theme
           </span>
        </div>
      </div>

      <div className="mt-6 pt-4 border-t border-border/50 flex justify-end">
        <Link href={`/report/${report.id}`} className="text-sm font-semibold text-primary flex items-center gap-1 group-hover:gap-2 transition-all">
          Open Editor <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </motion.div>
  );
}
