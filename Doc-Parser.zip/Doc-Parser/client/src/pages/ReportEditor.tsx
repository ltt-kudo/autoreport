import { useState, useEffect, useRef } from "react";
import { useRoute, Link } from "wouter";
import { useReport, useUpdateReport, useGenerateAI, useUploadFile } from "@/hooks/use-reports";
import { ReportPreview } from "@/components/ReportPreview";
import {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from "@/components/ui/resizable";
import {
  Layout,
  Type,
  Wand2,
  Save,
  Download,
  ChevronLeft,
  Loader2,
  Moon,
  Sun,
  FileCode,
  FileText,
  Paperclip,
  X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ReportEditor() {
  const [, params] = useRoute("/report/:id");
  const reportId = Number(params?.id);
  const { data: report, isLoading } = useReport(reportId);
  const updateReport = useUpdateReport();
  const generateAI = useGenerateAI();
  const uploadFile = useUploadFile();
  const { toast } = useToast();

  const [content, setContent] = useState("");
  const [title, setTitle] = useState("");
  const [theme, setTheme] = useState("modern");
  const [context, setContext] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [attachmentUrl, setAttachmentUrl] = useState<string | null>(null);
  const [attachmentName, setAttachmentName] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync with fetched data
  useEffect(() => {
    if (report) {
      setContent(report.content);
      setTitle(report.title);
      setTheme(report.theme);
      setAttachmentUrl(report.attachmentUrl || null);
      setAttachmentName(report.attachmentName || null);
    }
  }, [report]);

  // Auto-save debounce logic
  useEffect(() => {
    if (!report) return;
    
    // Don't save if nothing changed
    if (
      content === report.content && 
      title === report.title && 
      theme === report.theme &&
      attachmentUrl === report.attachmentUrl &&
      attachmentName === report.attachmentName
    ) return;

    const timer = setTimeout(() => {
      setIsSaving(true);
      updateReport.mutate(
        { id: reportId, title, content, theme, attachmentUrl, attachmentName },
        {
          onSuccess: () => setIsSaving(false),
          onError: () => setIsSaving(false),
        }
      );
    }, 1000);

    return () => clearTimeout(timer);
  }, [content, title, theme, attachmentUrl, attachmentName, reportId, report]);

  const handleGenerate = async () => {
    if (!context) {
      toast({
        title: "Context Required",
        description: "Please enter some data or topic in the context box first.",
        variant: "destructive",
      });
      return;
    }

    try {
      let finalContext = context;
      if (attachmentName) {
        finalContext += `\n\nNote: Analysis based on attached file: ${attachmentName}`;
      }

      const prompt = `Create a professional report about this topic. Use markdown. Include at least one chart using this syntax:
[Chart: Bar]
Label: Value
Label: Value
[End]
(or [Chart: Pie]). Make it detailed and structured with H1, H2.`;

      const result = await generateAI.mutateAsync({ prompt, context: finalContext });
      setContent((prev) => prev + "\n\n" + result.text);
      toast({
        title: "Content Generated",
        description: "AI has appended new content to your report.",
      });
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Could not generate content. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      const result = await uploadFile.mutateAsync(file);
      setAttachmentUrl(result.url);
      setAttachmentName(result.name);
      toast({
        title: "File Uploaded",
        description: `Successfully attached ${result.name}.`,
      });
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Could not upload file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const removeAttachment = () => {
    setAttachmentUrl(null);
    setAttachmentName(null);
  };

  const downloadHTML = () => {
    const previewElement = document.getElementById("report-preview");
    if (!previewElement) return;

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${title}</title>
          <style>
            body { font-family: ${theme === 'modern' ? 'sans-serif' : 'serif'}; padding: 40px; max-width: 800px; margin: 0 auto; line-height: 1.6; }
            h1, h2, h3 { color: #333; }
            img, svg { max-width: 100%; height: auto; }
            .chart-placeholder { border: 1px dashed #ccc; padding: 20px; text-align: center; background: #f9f9f9; margin: 20px 0; }
          </style>
        </head>
        <body>
          ${previewElement.innerHTML}
        </body>
      </html>
    `;

    const blob = new Blob([htmlContent], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, "_")}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const downloadMarkdown = () => {
    const blob = new Blob([content], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, "_")}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!report) return <div>Report not found</div>;

  return (
    <div className="h-screen flex flex-col bg-background text-foreground overflow-hidden">
      {/* Header Toolbar */}
      <header className="h-16 border-b border-border bg-card px-4 flex items-center justify-between shrink-0 shadow-sm z-10">
        <div className="flex items-center gap-4 flex-1">
          <Link href="/" className="p-2 hover:bg-accent rounded-full text-muted-foreground transition-colors">
            <ChevronLeft className="w-5 h-5" />
          </Link>
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="bg-transparent text-lg font-bold focus:outline-none focus:bg-accent/50 px-2 py-1 rounded-md transition-colors w-full max-w-md"
            placeholder="Report Title"
          />
          <div className="text-xs text-muted-foreground flex items-center gap-1.5 ml-2">
            {isSaving ? (
              <>
                <Loader2 className="w-3 h-3 animate-spin" /> Saving...
              </>
            ) : (
              <>
                <Save className="w-3 h-3" /> Saved
              </>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Theme Toggle */}
          <div className="flex bg-muted p-1 rounded-lg mr-2">
            <button
              onClick={() => setTheme("modern")}
              className={`p-1.5 rounded-md transition-all ${
                theme === "modern" ? "bg-white shadow-sm text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
              title="Modern Theme"
            >
              <Sun className="w-4 h-4" />
            </button>
            <button
              onClick={() => setTheme("classic")}
              className={`p-1.5 rounded-md transition-all ${
                theme === "classic" ? "bg-white shadow-sm text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
              title="Classic Theme"
            >
              <Moon className="w-4 h-4" />
            </button>
          </div>

          <div className="h-6 w-px bg-border mx-2" />

          {/* Export Actions */}
          <button onClick={downloadMarkdown} className="p-2 hover:bg-accent rounded-lg text-muted-foreground transition-colors" title="Download Markdown">
             <FileCode className="w-5 h-5" />
          </button>
          <button onClick={downloadHTML} className="p-2 hover:bg-accent rounded-lg text-muted-foreground transition-colors" title="Download HTML">
             <FileText className="w-5 h-5" />
          </button>
          <button className="hidden md:flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium shadow-md hover:shadow-lg hover:shadow-primary/20 transition-all">
             <Download className="w-4 h-4" /> Export PDF
          </button>
        </div>
      </header>

      {/* Main Split View */}
      <ResizablePanelGroup direction="horizontal" className="flex-1">
        
        {/* LEFT: Editor Panel */}
        <ResizablePanel defaultSize={50} minSize={30} className="bg-background flex flex-col relative z-0">
          
          {/* AI Context Bar */}
          <div className="p-4 border-b border-border bg-slate-50/50 backdrop-blur-sm">
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  placeholder="Enter context, data, or topic for AI generation..."
                  className="flex-1 px-3 py-2 rounded-lg border border-border bg-white text-sm focus:ring-2 focus:ring-primary/20 focus:border-primary outline-none transition-all"
                  onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
                />
                <button
                  onClick={handleGenerate}
                  disabled={generateAI.isPending}
                  className="px-4 py-2 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg text-sm font-medium shadow-md hover:shadow-lg hover:shadow-indigo-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  {generateAI.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
                  Generate
                </button>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploadFile.isPending}
                  className="flex items-center gap-2 text-xs font-medium text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-md transition-all border border-indigo-100"
                >
                  {uploadFile.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : <Paperclip className="w-3 h-3" />}
                  Attach Data File
                </button>

                {attachmentName && (
                  <div className="flex items-center gap-1.5 px-2 py-1 bg-amber-50 text-amber-700 rounded-md border border-amber-100 text-xs animate-in fade-in zoom-in duration-200">
                    <FileText className="w-3 h-3" />
                    <span className="max-w-[150px] truncate" title={attachmentName}>{attachmentName}</span>
                    <button 
                      onClick={removeAttachment}
                      className="p-0.5 hover:bg-amber-200 rounded-full transition-colors"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Markdown Editor */}
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="flex-1 w-full p-6 resize-none bg-transparent outline-none font-mono text-sm leading-relaxed text-slate-800 placeholder:text-slate-400"
            placeholder="# Start writing your report..."
            spellCheck={false}
          />
          
          {/* Syntax Helper Footer */}
          <div className="px-4 py-2 border-t border-border bg-muted/30 text-xs text-muted-foreground flex justify-between items-center">
            <span>Supports Markdown & Chart Syntax</span>
            <code className="bg-muted px-1.5 py-0.5 rounded border border-border">
              [Chart: Bar] Label: 10 ... [End]
            </code>
          </div>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* RIGHT: Preview Panel */}
        <ResizablePanel defaultSize={50} minSize={30} className="bg-muted/10 relative">
          <div className="absolute inset-0 overflow-hidden">
            <ReportPreview content={content} theme={theme} id="report-preview" />
          </div>
        </ResizablePanel>

      </ResizablePanelGroup>
    </div>
  );
}
