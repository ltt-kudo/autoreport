import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useReports, useCreateReport, useDeleteReport } from "@/hooks/use-reports";
import { ReportCard } from "@/components/ReportCard";
import { Plus, Search, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const [location, setLocation] = useLocation();
  const { data: reports, isLoading } = useReports();
  const createReport = useCreateReport();
  const deleteReport = useDeleteReport();
  const [search, setSearch] = useState("");

  const handleCreate = async () => {
    try {
      const newReport = await createReport.mutateAsync({
        title: "Untitled Report",
        content: "# New Report\n\nStart writing or use AI to generate content...",
        theme: "modern",
      });
      setLocation(`/report/${newReport.id}`);
    } catch (error) {
      console.error("Failed to create report", error);
    }
  };

  const filteredReports = reports?.filter((r) =>
    r.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Hero Section */}
      <div className="bg-primary/5 border-b border-primary/10 py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <h1 className="text-4xl md:text-5xl font-display font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-primary/60 mb-2">
                Smart Reports
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl">
                Create stunning data-driven reports in seconds using AI. 
                Visualize data, customize themes, and export with ease.
              </p>
            </div>
            
            <button
              onClick={handleCreate}
              disabled={createReport.isPending}
              className="group relative inline-flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-xl font-semibold shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 overflow-hidden"
            >
              <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
              {createReport.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <Plus className="w-5 h-5" />
              )}
              <span>Create New Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 mb-8">
          <h2 className="text-2xl font-bold">Your Reports</h2>
          <div className="relative w-full sm:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search reports..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-border bg-background focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all outline-none"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-muted/50 rounded-2xl animate-pulse border border-border/50" />
            ))}
          </div>
        ) : filteredReports?.length === 0 ? (
          <div className="text-center py-20 bg-muted/30 rounded-3xl border border-dashed border-border">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <FileText className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No reports found</h3>
            <p className="text-muted-foreground max-w-sm mx-auto mb-6">
              {search ? "Try a different search term." : "Get started by creating your first smart report."}
            </p>
            {!search && (
              <button
                onClick={handleCreate}
                className="text-primary font-medium hover:underline"
              >
                Create a report now
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence>
              {filteredReports?.map((report) => (
                <ReportCard
                  key={report.id}
                  report={report}
                  onDelete={(id) => deleteReport.mutate(id)}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </main>
    </div>
  );
}

// Icon for empty state
function FileText(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z" />
      <polyline points="14 2 14 8 20 8" />
    </svg>
  );
}
