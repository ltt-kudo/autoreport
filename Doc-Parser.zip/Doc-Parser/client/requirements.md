## Packages
react-markdown | Rendering markdown content
recharts | Rendering charts in the report preview
react-resizable-panels | Split screen editor layout
lucide-react | Icons
framer-motion | Animations and transitions
clsx | Class name utility
tailwind-merge | Class name utility
date-fns | Date formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  serif: ["Playfair Display", "serif"],
  mono: ["Fira Code", "monospace"],
}
