import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default("Untitled Report"),
  content: text("content").notNull(), // Markdown content
  theme: text("theme").notNull().default("modern"),
  attachmentUrl: text("attachment_url"), // URL or path to attached file
  attachmentName: text("attachment_name"), // Original name of the file
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReportSchema = createInsertSchema(reports).omit({
  id: true,
  createdAt: true,
});

export type Report = typeof reports.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
