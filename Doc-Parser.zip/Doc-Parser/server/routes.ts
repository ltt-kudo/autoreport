import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { GoogleGenerativeAI } from "@google/generative-ai";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: "uploads/",
    filename: (req, file, cb) => {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
    },
  }),
});

// Ensure uploads directory exists
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // File upload endpoint
  app.post("/api/upload", upload.single("file"), (req, res) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    res.json({
      url: `/uploads/${req.file.filename}`,
      name: req.file.originalname,
    });
  });

  // Serve uploaded files
  app.use("/uploads", (req, res, next) => {
    res.setHeader("Content-Type", "application/octet-stream");
    next();
  }, (req, res, next) => {
    // Basic static serving
    const filePath = path.join(process.cwd(), "uploads", req.path);
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).end();
    }
  });

  // AI Generation Route with File Content Support
  app.post(api.ai.generate.path, async (req, res) => {
    try {
      const { prompt, context } = api.ai.generate.input.parse(req.body);

      // Priority: use Replit AI Integrations environment variables
      const apiKey = process.env.AI_INTEGRATIONS_GEMINI_API_KEY || process.env.GEMINI_API_KEY;
      const baseUrl = process.env.AI_INTEGRATIONS_GEMINI_BASE_URL;

      if (!apiKey) {
        return res.status(500).json({ 
          message: "Gemini API Key is not configured." 
        });
      }

      // Initialize with base URL and correct configuration for Replit AI Integrations
      const genAI = new GoogleGenerativeAI(apiKey);
      
      // Use gemini-3-flash-preview as it is the most stable and updated for Replit AI integrations
      const model = genAI.getGenerativeModel({ 
        model: "gemini-3-flash-preview",
      }, {
        baseUrl: baseUrl || undefined,
        apiVersion: "" // Required for AI integrations
      });

      const systemInstruction = `Bạn là chuyên gia thiết kế báo cáo. Chuyển dữ liệu người dùng thành báo cáo đẹp.
      Định dạng: # Tiêu đề, ## Tiêu đề phụ, > Trích dẫn, [Biểu đồ: Cột] hoặc [Biểu đồ: Tròn], Nhãn: Giá trị, [Kết thúc].`;

      let finalPrompt = `${systemInstruction}\n\nContext: ${context || ''}\n\nTask: ${prompt}`;

      const result = await model.generateContent(finalPrompt);
      const response = result.response;
      const text = response.text();

      res.json({ text });
    } catch (e: any) {
      console.error("AI Generation Error:", e);
      res.status(500).json({ message: e.message || "Failed to generate content" });
    }
  });

  // Report Routes
  app.get(api.reports.list.path, async (req, res) => {
    const reports = await storage.getReports();
    res.json(reports);
  });

  app.get(api.reports.get.path, async (req, res) => {
    const report = await storage.getReport(Number(req.params.id));
    if (!report) return res.status(404).json({ message: "Report not found" });
    res.json(report);
  });

  app.post(api.reports.create.path, async (req, res) => {
    const input = api.reports.create.input.parse(req.body);
    const report = await storage.createReport(input);
    res.status(201).json(report);
  });

  app.put(api.reports.update.path, async (req, res) => {
    const input = api.reports.update.input.parse(req.body);
    const report = await storage.updateReport(Number(req.params.id), input);
    res.json(report);
  });

  app.delete(api.reports.delete.path, async (req, res) => {
    await storage.deleteReport(Number(req.params.id));
    res.status(204).end();
  });

  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getReports();
  if (existing.length === 0) {
    await storage.createReport({
      title: "Sample Sales Report",
      content: `# BÁO CÁO DOANH SỐ QUÝ 1\n> Tăng trưởng vượt mong đợi\n\n## Tổng quan\nDoanh số quý này đạt mức kỷ lục nhờ sự ra mắt của dòng sản phẩm mới.\n\n[Biểu đồ: Cột]\nTháng 1: 120\nTháng 2: 150\nTháng 3: 180\n[Kết thúc]\n\n## Phân bổ theo khu vực\n[Biểu đồ: Tròn]\nMiền Bắc: 40\nMiền Trung: 25\nMiền Nam: 35\n[Kết thúc]\n`,
      theme: "modern",
    });
  }
}
